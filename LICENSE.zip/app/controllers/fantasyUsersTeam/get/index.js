const getPlayersByUserId = require('./getTeamByUserId')

const getTeamById = require('./getTeamById')

module.exports ={
    getPlayersByUserId,
    getTeamById
    
}