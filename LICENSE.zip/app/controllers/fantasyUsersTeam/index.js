const get = require('./get')
const post = require('./post/player')
const patch = require('./patch/playerPatch')

module.exports ={
    get,
    post,
    patch
}