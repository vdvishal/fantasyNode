 const get = require('./get')


module.exports ={
    get
}