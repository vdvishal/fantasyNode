const post = require('./contest')
 
module.exports ={
    post
}