const getPlayers = require('./getPlayers')
const getTeam = require('./getTeam')

module.exports ={
    getPlayers,
    getTeam
    
}