const get = require('./get')
const post = require('./post/player')

module.exports ={
    get,
    post
}