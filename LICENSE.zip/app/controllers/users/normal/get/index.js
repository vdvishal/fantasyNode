const activateAccount = require('./activateAccount')
const profile = require('./profile')
const refToken = require('./refreshToken')
 
module.exports = {
    profile,
    activateAccount,
    refToken
}