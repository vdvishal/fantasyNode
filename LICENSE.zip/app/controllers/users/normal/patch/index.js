 const patchProfile = require('./profile')
 
module.exports = {
    patchProfile
}