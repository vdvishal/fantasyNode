 
const account = require('./normal')
const refresh = require('./refresh/get')

module.exports = {
    account,
    refresh
}