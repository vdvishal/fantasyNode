const post = require('./join')
 
module.exports = post