let join = require('./join')
let joinCustom = require('./joinCustom')
let createCustom = require('./custom')
let joinVs = require('./joinVs')

module.exports = {
    join, 
    joinCustom,
    createCustom,
    joinVs 
}