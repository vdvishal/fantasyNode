let get = require('./get')
let post = require('./post')

module.exports = {
    get,
    post
}