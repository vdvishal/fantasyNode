const 
    amqp = require("amqplib/callback_api"),
    logger = require('winston')


exports.connect = () => {
    
}

